open Types;;

let rec cherche liste el = match liste with
| [] -> false
| t::q -> (if (el=t)
	then true
	else cherche q el)
;;

let rec ecr_arr clau list_ded f temoin= match clau with
| [] -> ()
| t::q -> (print_int t;print_endline "TAAA";if (t=temoin)
	then ecr_arr q list_ded f temoin
	else (if (cherche list_ded (-t))
		then (output_string f (string_of_int (-t));
			output_string f " -> ";
			output_string f (string_of_int (temoin));
			output_string f "\n";
			ecr_arr q list_ded f temoin)
		else ecr_arr q list_ded f temoin))
;;

let rec ecr_fich f list_ded ded tab_ded tab_clau= match ded with
| [] -> ()
| t::q -> print_int t;print_endline "toto";ecr_arr (tab_clau.(tab_ded.(abs t)))  list_ded f t; ecr_fich f list_ded q tab_ded tab_clau
;;

let confl list_ded tab_ded tab_clau=
let f=open_out "conflit.dot" 
and ded= List.tl list_ded in
output_string f "digraph conflit {\n";
output_string f "node  [style=filled,color=\" 0.7 1.0 1.0\"];\n";
output_string f (string_of_int (List.hd list_ded));
output_string f "\nnode  [style=filled,color=\" 0.4 1.0 1.0\"];\n";
ecr_fich f list_ded ded tab_ded tab_clau;
output_string f "}";
close_out f;;


















